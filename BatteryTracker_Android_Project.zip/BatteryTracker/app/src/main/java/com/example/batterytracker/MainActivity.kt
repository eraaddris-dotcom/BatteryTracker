package com.example.batterytracker

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(40, 100, 40, 60)
        }
        sv.addView(root); setContentView(sv)
        val req = PeriodicWorkRequestBuilder<BatteryWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("log", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    override fun onResume() { super.onResume(); BatteryWorker.log(this); render() }

    private fun title(t: String) = root.addView(TextView(this).apply {
        text = t; textSize = 20f; setPadding(0, 40, 0, 12); setTypeface(typeface, android.graphics.Typeface.BOLD)
    })
    private fun line(t: String) = root.addView(TextView(this).apply { text = t; textSize = 16f; setPadding(0, 6, 0, 6) })

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun render() {
        root.removeAllViews()

        // 1) حالة البطارية
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))!!
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        title("🔋 حالة البطارية")
        line("المستوى: $level%  ${if (charging) "(يشحن)" else ""}")
        line("الحرارة: $temp °م   |   الجهد: $volt mV")
        val drain = BatteryWorker.drainPerHour(this)
        line(
            if (drain != null) "متوسط الاستهلاك (آخر 24 ساعة): ${"%.1f".format(drain)}% في الساعة"
            else "جارٍ جمع البيانات... اترك التطبيق يعمل عدة ساعات ليحسب المعدل."
        )

        title("📈 مستوى البطارية خلال 24 ساعة")
        root.addView(ChartView(this, BatteryWorker.history(this)))

        // 2) أكثر التطبيقات استخداماً
        title("📱 أكثر التطبيقات استخداماً (آخر 24 ساعة)")
        if (!hasUsageAccess()) {
            line("يحتاج التطبيق صلاحية «الوصول إلى بيانات الاستخدام».")
            root.addView(Button(this).apply {
                text = "منح الصلاحية"
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            })
        } else {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val stats = usm.queryAndAggregateUsageStats(now - 24 * 3600_000L, now)
                .values.filter { it.totalTimeInForeground > 60_000 }
                .sortedByDescending { it.totalTimeInForeground }.take(15)
            if (stats.isEmpty()) line("لا توجد بيانات بعد.")
            stats.forEach {
                val label = try {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(it.packageName, 0)).toString()
                } catch (e: Exception) { it.packageName }
                val m = it.totalTimeInForeground / 60000
                line("• $label — ${m / 60} س ${m % 60} د")
            }
            line("ملاحظة: الترتيب حسب وقت الاستخدام الأمامي كمؤشر تقريبي للاستهلاك.")
        }

        // 3) الإعدادات المستهلكة للطاقة
        title("⚙️ الإعدادات المؤثرة")
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val tips = mutableListOf<String>()
        val bright = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 0) * 100 / 255
        val timeout = Settings.System.getInt(contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, 0) / 1000
        val wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
        val loc = (getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
        line("السطوع: $bright%")
        line("مهلة إطفاء الشاشة: $timeout ثانية")
        line("الواي فاي: ${if (wifi) "مفعّل" else "متوقف"}")
        line("الموقع: ${if (loc) "مفعّل" else "متوقف"}")
        line("وضع توفير الطاقة: ${if (pm.isPowerSaveMode) "مفعّل" else "متوقف"}")
        if (bright > 70) tips += "السطوع مرتفع — خفضه أو فعّل السطوع التكيفي."
        if (timeout > 60) tips += "مهلة الشاشة طويلة — اجعلها 30 ثانية."
        if (loc) tips += "الموقع مفعّل — اجعله «أثناء استخدام التطبيق» فقط."
        if (!pm.isPowerSaveMode && level < 30) tips += "البطارية منخفضة — فعّل توفير الطاقة."
        tips += "على S23: معدل التحديث التكيفي (الإعدادات ← العرض ← سلاسة الحركة) يوفر طاقة، والوضع الداكن يساعد."
        title("💡 اقتراحات")
        tips.forEach { line("• $it") }

        root.addView(Button(this).apply {
            text = "فتح إعدادات البطارية في سامسونج"
            setOnClickListener { startActivity(Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }
        })
    }
}
