package com.example.batterytracker

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File

class BatteryWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result { log(applicationContext); return Result.success() }

    companion object {
        fun log(c: Context) {
            val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val ch = if (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL) 1 else 0
            File(c.filesDir, "log.csv").appendText("${System.currentTimeMillis()},$level,$ch\n")
        }

        fun history(c: Context): List<Pair<Long, Int>> {
            val f = File(c.filesDir, "log.csv"); if (!f.exists()) return emptyList()
            val since = System.currentTimeMillis() - 24 * 3600_000L
            return f.readLines().mapNotNull {
                val p = it.split(","); if (p.size == 3) Pair(p[0].toLong(), p[1].toInt()) else null
            }.filter { it.first >= since }
        }

        /** متوسط نسبة الاستهلاك في الساعة خلال آخر 24 ساعة (بدون فترات الشحن) */
        fun drainPerHour(c: Context): Double? {
            val f = File(c.filesDir, "log.csv"); if (!f.exists()) return null
            val since = System.currentTimeMillis() - 24 * 3600_000L
            val rows = f.readLines().mapNotNull {
                val p = it.split(",")
                if (p.size == 3) Triple(p[0].toLong(), p[1].toInt(), p[2].toInt()) else null
            }.filter { it.first >= since }
            var drop = 0; var ms = 0L
            for (k in 1 until rows.size) {
                val a = rows[k - 1]; val b = rows[k]
                if (a.third == 0 && b.third == 0 && b.second <= a.second && b.first - a.first < 2 * 3600_000L) {
                    drop += a.second - b.second; ms += b.first - a.first
                }
            }
            return if (ms > 0) drop / (ms / 3600000.0) else null
        }
    }
}
