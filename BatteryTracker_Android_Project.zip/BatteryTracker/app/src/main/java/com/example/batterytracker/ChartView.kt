package com.example.batterytracker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class ChartView(c: Context, private val pts: List<Pair<Long, Int>>) : View(c) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(46, 160, 67); strokeWidth = 6f; style = Paint.Style.STROKE }
    private val grid = Paint().apply { color = Color.LTGRAY; strokeWidth = 2f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 30f }

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), 420)

    override fun onDraw(cv: Canvas) {
        val l = 90f; val r = width - 20f; val t = 20f; val b = height - 20f
        for (v in listOf(0, 50, 100)) {
            val y = b - (b - t) * v / 100f
            cv.drawLine(l, y, r, y, grid); cv.drawText("$v%", 5f, y + 10f, txt)
        }
        if (pts.size < 2) { cv.drawText("لا توجد بيانات كافية بعد", l + 20f, height / 2f, txt); return }
        val t0 = pts.first().first; val span = (pts.last().first - t0).coerceAtLeast(1L)
        for (k in 1 until pts.size) {
            val x1 = l + (r - l) * (pts[k - 1].first - t0) / span; val y1 = b - (b - t) * pts[k - 1].second / 100f
            val x2 = l + (r - l) * (pts[k].first - t0) / span; val y2 = b - (b - t) * pts[k].second / 100f
            cv.drawLine(x1, y1, x2, y2, line)
        }
    }
}
